# `vscode-js-profile-table`

> TODO: description

## Usage

```
const vscodeJsProfileTable = require('vscode-js-profile-table');

// TODO: DEMONSTRATE API
```
